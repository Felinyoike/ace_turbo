﻿
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Ace Turbo | Quality Counts</title>

    <!-- Favicon  -->
    <link rel="shortcut icon" href="img/core-img/favicon2.ico" type="image/ico" />

    <!-- Style CSS -->

    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/task.css">
    <link rel="stylesheet" href="css/fontawesome-free/css/all.min.css">


    <!--<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700|Work+Sans:300,400,500,600,700">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/owl.carousel.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/themify-icons.css">
	<link rel="stylesheet" href="css/magnific-popup.css"> -->

</head>
<style>
@media only screen and (max-width: 1024px) {
#cartl{
    width:79px !important;
}
}
@media only screen and (max-device-width: 1024px) {
    #cartl{
    width:79px !important;
}
}
@media only screen and (max-width: 990px) {
    .cart101{
    display:block !important;
}
}
@media only screen and (max-device-width: 768px) {
    .cart101{
    display:block !important;
}
}
</style>
<body>
    <!-- Preloader Start -->
    <div id="preloader">
        <div class="preload-content">
            <div id="world-load"></div>
        </div>
    </div> 
    <!-- Preloader End -->

    <!-- ***** Header Area Start ***** -->
   
    <header class="header-area2">
        <div class="container">
            <div class="row">
                <div class="col-12" style="padding:1px !important">
                    <nav class="navbar navbar-expand-lg">
                  
                        <!-- Logo -->
                        <a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="Logo" style="height:50px; width:70px; margin-top:-15px"></a>
                        <a href='cart.php' id='cartl' class='nav-item nav-link active cart101' style="margin-left:10px; width: 150px !important;margin-top:-5px; display:none">
                                    <h5 class=' cart text-white' style=' font-size:16px;'>
                                            <i class='fas fa-shopping-cart'></i>
                                            <span id='cart-count' class='text-white bg-dark' style='margin-left:5px'>0</span></h5>
                                    </a>                        <!-- Navbar Toggler -->
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#worldNav" aria-controls="worldNav" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                        <!-- Navbar -->
                        <div class="collapse navbar-collapse" id="worldNav">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item active">
                                    <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item dropdown" style="width: 130px">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Turbo Finder</a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="garretTurbos.php">Garret Turbos</a>
                                        <a class="dropdown-item" href="holsetTurbos.php">Holset Turbos</a>
                                        <a class="dropdown-item" href="ihiTurbos.php">IHI Turbos</a>
                                        <a class="dropdown-item" href="mitsuTurbos.php">Mitsubishi Turbos</a>
                                        <a class="dropdown-item" href="schwitzerTurbos.php">Schwitzer Turbos</a>
                                        <a class="dropdown-item" href="toyotaTurbos.php">Toyota Turbos</a>
                                        <a class="dropdown-item" href="kkkTurbos.php">KKK Turbos</a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown" style="width: 100px">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services</a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="turboRepairs.php">Turbo Repairs</a>
                                        <a class="dropdown-item" href="remanufactured.php">Remanufactured Turbos</a>
                                        <a class="dropdown-item" href="turboParts.php">Turbo Parts</a>
                                        <a class="dropdown-item" href="turboFitting.php">Turbo Fitting</a>
                                        <a class="dropdown-item" href="newTurbos.php">New Turbos</a>
                                    </div>
                                </li>
                                <li class="nav-item" style="width: 125px">
                                    <a class="nav-link" href="franchise.php">Franchise Opp.</a>
                                </li>
                                <li class="nav-item dropdown" style="width: 120px">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Legal Stuff</a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="businessPolicy.php">Business Policy</a>
                                        <a class="dropdown-item" href="deliveryPolicy.php">Delivery Policy</a>
                                        <a class="dropdown-item" href="refund.php">Refund/Cancellations</a>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php">Contact</a>
                                </li>
                                <li class="nav-item">
                                    <button class="button" type="submit" style="width:110px; margin-top: -20px;background-image: linear-gradient(to bottom right, #2cadec, #0a4780);"><span><a class="nav-link" href="#">Sign in</a></span></button>
                                </li>
                                    <a href='cart.php' id='cartl' class='nav-item nav-link active' style="margin-left:20px; width: 100px">
                                    <h5 class=' cart text-white' style=' font-size:16px;'>
                                            <i class='fas fa-shopping-cart'></i>
                                            <span id='cart-count101' class='text-white bg-dark' style='margin-left:5px'>0</span></h5>
                                    </a>                            </ul>
                            <!-- Search Form  -->

                        </div>
                        
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->
<style>
.contact-form{
    background: #fff;
    margin-top: 1%;
    margin-bottom: 1%;
    width: 100%;
}

.contact-image{
    text-align: center;
}
.contact-image img{
   
    width: 85%;
    margin-top: -3%;
}
.contact-form form{
    padding: 1%;
}
.contact-form form .row{
    margin-bottom: -9%;
}
.contact-form h3{
    margin-bottom: 3%;
    margin-top: -6%;
    text-align: center;
    color: #0062cc;
}
.contact-form .btnContact {
    width: 50%;
    border: none;
    border-radius: 1rem;
    padding: 1.5%;
    background: #dc3545;
    font-weight: 600;
    color: #fff;
    cursor: pointer;
}
.btnContactSubmit
{
    width: 50%;
    border-radius: 1rem;
    padding: 1.5%;
    color: #fff;
    background-color: #0062cc;
    border: none;
    cursor: pointer;
}

.btnfield{
        margin-left:0px !important;
        padding-left:0px !important;
        width: 100% !important;
    }
    .contact-form button{
        background-image: linear-gradient(to bottom right, #2cadec, #0a4780);
		color: #fff;
        text-shadow: 2px 2px 4px #000000;
		font-weight: 600;
		width: 40% !important;
	}
</style>




    <!-- ********** Hero Area End ********** -->

    <div class="main-content-wrapper section-padding-50" style="margin-top:65px">
        <div class="flex-container">
            <div class="flex-item-left"><a style="font-size:16px; color:black; margin-top:-30px !important" href="tel:01279-817451"><i class="fas fa-phone-square"> 01279-817451</i></a></div>
            <div class="flex-item-mid"><p> Version 3.6 </p></div>
            <div class="flex-item-right"> <a style="font-size:16px; color:black" href="mailto:contact@aceturbo.co.uk">				<i class="fas fa-envelope"> Email Us</i></a></div>
        </div><hr>
        <div class="container" style=' margin-top:0px;'>
            
            <div class="row">
                <!-- ============= Post Content Area Start ============= -->
                
                <div class="col-12 col-lg-3">
                    <h4 style="text-align: center; font-weight:bold">FIND YOUR<span style="color:red"> TURBO</span></h4>
                    <div class='portform' style="width: 100%">
                    
                        <form method='post' action='valreg.php' >
                            <div class='form-group'>
                                <!--<label for='sid' style="font-weight:bold; margin-left:-20px">REGISTRATION NUMBER :</label>-->
                                <div class="row" style="margin-top:12px">
                            <div class="col-12 col-sm-8" style=" margin:0; padding:0">
                                <input style="background-color: #ffd800; width:100%;"   type='text' name='REG' class='form-control' id='sid' placeholder='YOUR REG' required/>
                                </div>
                                <div class="col-12 col-sm-4" id='reggo' style="margin-left:0; padding-left:0; ">
                              <button style='width:70%; background-color:#11428F; margin-left:0 !important; height:95%; border-radius:8px;' class='button btn-danger' id='regb' name='regb' type='submit'><span>Go!</span></button>
                              </div>
                            </div>
                            
                            </div>
                        </form>
                        <div class="separator">OR</div>
                        <form method='post' action='valturbo.php' >
                            <div class='form-group'>
                                <label for='turbo' style="font-weight:bold; margin-left:-30px">Turbo Search:</label>
                                <div class="row" style="margin-top:0px">
                            <div class="col-12 col-sm-8" style=" margin:0; padding:0">
                                <input style="background-image: linear-gradient(to bottom right, #2cadec, #0a4780); width:100%; border: 1px solid black"   type='text' name='turbo' class='form-control' id='turbo' placeholder='Turbo Number' required/>
                                </div>
                                <div class="col-12 col-sm-4" id='turbogo' style="margin-left:0; padding-left:0; ">
                              <button style='width:70%; background-color:#11428F; margin-left:0 !important; height:95%; border-radius:8px;' class='button btn-danger'  id='turbob' name='turb' type='submit'><span>Go!</span></button>
                              </div>
                            </div>
                            
                            </div>
                        </form>
                        <div class="separator">OR</div>
                        <form style="text-align:center; width:85%" method='post' action='valvehicle.php'  id='mainFilter' onsubmit='return validateForm()'>
                        <p style="font-weight:bold; color:black; font-size:18px; margin-top:0px; padding-top:0px; margin-left:20%">Select Your Vehicle</p>
                            <div class='form-group'>
                                <select name='make' id='make' class='form-control' onchange='chooseModel(this.value)'>
                                    <option disabled selected value=''>Select Make:</option>";
                                    <option value = '1009'>Abarth</option><option value = '5'>Alfa Romeo</option><option value = '10'>Audi</option><option value = '20'>BMW</option><option value = '1014'>BOUDOUIN</option><option value = '15'>Bentley</option><option value = '25'>Buick</option><option value = '1027'>Cadillac</option><option value = '1026'>Caterpillar</option><option value = '30'>Chevrolet</option><option value = '35'>Chrysler</option><option value = '40'>Citroen</option><option value = '1029'>Cupra </option><option value = '1033'>DEUTZ</option><option value = '1006'>DS</option><option value = '1003'>Dacia</option><option value = '45'>Daewoo</option><option value = '50'>Daihatsu</option><option value = '55'>Dodge</option><option value = '60'>Ferrari</option><option value = '65'>Fiat</option><option value = '70'>Fiat Allis</option><option value = '75'>Fiat Iveco</option><option value = '1031'>Fisker</option><option value = '80'>Ford</option><option value = '85'>Honda</option><option value = '95'>Hyundai</option><option value = '1013'>Infiniti</option><option value = '100'>Isuzu</option><option value = '105'>Iveco</option><option value = '1001'>Iveco-Sofim</option><option value = '110'>Jaguar</option><option value = '115'>Jeep</option><option value = '120'>Kia</option><option value = '135'>LDV</option><option value = '140'>LEXUS</option><option value = '125'>Lancia</option><option value = '130'>Land Rover</option><option value = '1005'>Lincoln</option><option value = '1032'>London Taxi </option><option value = '145'>Lotus</option><option value = '1028'>MAN</option><option value = '170'>MG</option><option value = '1012'>MITSUBISHI FUSO TRUCK & BUS</option><option value = '1034'>Make</option><option value = '150'>Maserati</option><option value = '155'>Mazda</option><option value = '1004'>Mercedes - Benz (Commercial)</option><option value = '165'>Mercedes-Benz</option><option value = '175'>Mini</option><option value = '180'>Mitsubishi</option><option value = '185'>Nissan</option><option value = '190'>OPEL VAUXHALL</option><option value = '195'>Peugeot</option><option value = '200'>Pontiac</option><option value = '205'>Porsche</option><option value = '215'>Puch</option><option value = '220'>Renault</option><option value = '225'>Roewe</option><option value = '230'>Rover</option><option value = '240'>Saab</option><option value = '1030'>Saturn</option><option value = '245'>Seat</option><option value = '250'>Skoda</option><option value = '255'>Smart</option><option value = '260'>SsangYong</option><option value = '265'>Subaru</option><option value = '270'>Suzuki</option><option value = '280'>Toyota</option><option value = '290'>Volkswagen</option><option value = '295'>Volvo</option><option value = '1015'>Volvo Truck </option></select>                            </div>
                            <div class='form-group'>
                                <select name='model' id='model' class='form-control' onchange='chooseYear(this.value)'>
                                    <option value='' disabled selected>Select Model:</option>
                                    
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='year' id='year' class='form-control' onchange='chooseEngine(this.value)'>
                                    <option value='' selected>Select Year</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='engine' id='engine' class='form-control' onchange='chooseBHP(this.value)'>
                                    <option value='' selected>Engine Size</option>
                                </select>
                            </div>
                            <div class='form-group'>
                                <select name='bhp' id='bhp' class='form-control' onchange=''>
                                    <option value='' selected>Select BHP</option>
                                </select>
                            </div>

                            <button style='margin-left:30px; background-color:#11428F; width:60%' id='vehgo' class='button' name='reg' type='submit'><span>Go!</span></button>
                        
                        </form>
                    </div>
                    
                </div>
                
                <!-- ========== Sidebar Area ========== -->
                <div class="col-12 col-lg-9">
                        <!-- Single Blog Post -->
                        <div class="single-blog-post post-style-4 d-flex align-items-center wow fadeInUpBig" data-wow-delay="0.1s">
                            <!-- Post Content -->
                            <div class="post-content">
                            
                            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                                        <!--<li data-target="#carouselExampleIndicators" data-slide-to="2"></li>-->
                                    </ol>
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                        <img class="d-block w-100" src="img/blog-img/IMG5.jpg" alt="First slide">
                                        </div>
                                        <div class="carousel-item">
                                        <img class="d-block w-100" src="img/blog-img/Banner3.jpg" alt="Second slide">
                                        </div>
                                        <!--<div class="carousel-item">
                                        <img class="d-block w-100" src="img/blog-img/IMG.jpg" alt="Third slide">
                                        </div>-->
                                    </div>
                                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </div>
                                
                                </div>
                        </div>
                </div> 
            </div>
            <div class="world-latest-articles">
                <div class="row">
                    <div class="col-12 col-md-8 col-lg-3">
                        <br>
                        <div class="post-sidebar-area wow fadeInUpBig" data-wow-delay="0.1s" style=" width:100%; margin-left:-5px;">
                            <div class="sidebar-widget-area" style="margin-top:10px;"> 
                                <h4 style="text-align: center; font-weight:bold;">Manufacturers</h4>
                                <div class="row justify-content-center">
                                    <div class="col-12 col-lg-4">
                                    <div class="card img-hover-zoom">
                                        <img src="img/AlfaRomeo.png" alt="AlfaR" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                    <div class="col-12 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/Audii.png" alt="Audi" style=" width: 100%">
                                        
                                        </div> 
                                    </div>
                                
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/bmw.png" alt="BMW" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                </div>
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-lg-4">
                                    <div class="card img-hover-zoom">
                                        <img src="img/Buick.png" alt="Buick" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/chrys.png" alt="Chrysler" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/Citroen.png" alt="Citroen" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                </div>
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-lg-4">
                                    <div class="card img-hover-zoom">
                                        <img src="img/bent.png" alt="Bentley" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/daewoo.png" alt="Daewoo" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/dihat.png" alt="Daihatsu" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                </div>
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-lg-4">
                                    <div class="card img-hover-zoom">
                                        <img src="img/Ferrari.png" alt="Ferrari" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img style="border-radius:4px" src="img/Fiat.jpg" alt="Fiat" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/ford.png" alt="Ford" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                </div>
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-lg-4">
                                    <div class="card img-hover-zoom">
                                        <img src="img/hyundai.png" alt="Hyundai" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img style="border-radius:4px" src="img/isuzu.png" alt="Isuzu" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/ivecoo.jpg" alt="Iveco" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                </div>
                                
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-lg-4">
                                    <div class="card img-hover-zoom">
                                        <img src="img/jeep.jpg" alt="Jeep" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/Kia.png" alt="Kia" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/lancia.jpg" alt="Lancia" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                </div>
                                
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-lg-4">
                                    <div class="card img-hover-zoom">
                                        <img src="img/LDV.png" alt="LDV" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img style="border-radius:4px" src="img/lotus.jpg" alt="Lotus" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/maserati.jpg" alt="Maserati" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                </div>
                                <!-- new -->
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-lg-4">
                                    <div class="card img-hover-zoom">
                                        <img src="img/benz.jpg" alt="Mercedes Benz" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/MG.png" alt="MG" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/mini.jpg" alt="Mini" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                </div>
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-lg-4">
                                    <div class="card img-hover-zoom">
                                        <img src="img/nissan.png" alt="Nissan" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/opel.jpg" alt="Opel" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/vaux.jpg" alt="Vaux" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                </div>
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-lg-4">
                                    <div class="card img-hover-zoom">
                                        <img src="img/pontaic.png" alt="Pontaic" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/porsche.png" alt="Porsche" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/puch.jpg" alt="Puch" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                </div>
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-lg-4">
                                    <div class="card img-hover-zoom">
                                        <img src="img/roewe.jpg" alt="Roewe" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/saab.png" alt="Saab" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/seat.png" alt="Seat" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                </div>
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-lg-4">
                                    <div class="card img-hover-zoom">
                                        <img src="img/smart.jpg" alt="Smart" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/ssang.png" alt="SsangYong" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/subaro.png" alt="Subaro" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                </div>
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-lg-4">
                                    <div class="card img-hover-zoom">
                                        <img src="img/toyota.png" alt="Toyota" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                    
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/volks.jpg" alt="Volkswagen" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/volvo.jpg" alt="Volvo" style="width:100%">
                                        
                                        </div> 
                                    </div>
                                </div>
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/rover.jpg" alt="Rover" style="width:100%">
                                        
                                        </div> 
                                        
                                    </div>
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/suzuki.jpg" alt="Suzuki" style="width:100%">
                                        
                                        </div> 
                                        
                                    </div>
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/skoda.png" alt="Skoda" style="width:100%">
                                        
                                        </div> 
                                        
                                    </div>
                                </div>
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/renault.jpg" alt="Renault" style="width:100%">
                                        
                                        </div> 
                                        
                                    </div>
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/peugeot.jpg" alt="Peugeot" style="width:100%">
                                        
                                        </div> 
                                        
                                    </div>
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/mitsu.jpg" alt="Mitsubishi" style="width:100%">
                                        
                                        </div> 
                                        
                                    </div>
                                </div>
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/mazda.jpg" alt="mazda" style="width:100%">
                                        
                                        </div> 
                                        
                                    </div>
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/landrover.png" alt="Landrover" style="width:100%">
                                        
                                        </div> 
                                        
                                    </div>
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/jaguar.jpg" alt="Jaguar" style="width:100%">
                                        
                                        </div> 
                                        
                                    </div>
                                </div>
                                <div class="row justify-content-center" style="margin-top:10px">
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/honda.jpg" alt="Honda" style="width:100%">
                                        
                                        </div> 
                                        
                                    </div>
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/Dodge.png" alt="Dodge" style="width:100%">
                                        
                                        </div> 
                                        
                                    </div>
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/Dacia.png" alt="Dacia" style="width:100%">
                                        
                                        </div> 
                                        
                                    </div>
                                </div>
                                <div class="row justify-content-center mb-2" style="margin-top:10px">
                                    <div class="col-12 col-md-8 col-lg-4">
                                        <div class="card img-hover-zoom">
                                        <img src="img/chev.png" alt="Cheverlot" style="height: 50px; width:100%">
                                        
                                        </div> 
                                        
                                    </div>
                                </div>
                            </div>
                            <!-- Widget Area -->
                            <div class="sidebar-widget-area">
                                <h5 class="title" style="border-top:2px solid #f1f1f1; border-bottom:2px solid #f1f1f1">Follow us</h5>
                                <div class="widget-content">
                                    <div class="social-area d-flex justify-content-between">
                                        <a href="https://www.facebook.com/aceturbo.uk"><i style="color:#1877F2; font-size:24px" class="fab fa-facebook-f"></i></a>
                                        <a href="http://www.twitter.com"><i style="color:#50ABF1; font-size:24px" class="fab fa-twitter"></i></a>
                                        <a href="https://www.linkedin.com/company/aceturbo-uk/"><i style="color:#0077B5; font-size:24px" class="fab fa-linkedin "></i></a>
                                        <a href="https://www.instagram.com/ace.turbouk/"><i style="color:#BB1971; font-size:24px" class="fab fa-instagram"></i></a>                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
					
					
					
					
					    <div class="col-12 col-md-8 col-lg-9 articlee wow fadeInUpBig" data-wow-delay="0.1s">
    
    <div class="container contact-form">
            <div class="contact-image">
                <img src="img/TurboRequest.png" alt="rocket_contact"/>
            </div>
            <form action="valcontact1.php" method="post" onsubmit="return formValidation()">
               <div class="row">
                    <div class="col-md-6">


                        <div class="form-group">
                            <b>Full Name: </b>
                            <input type="text" name="name" id="name" class="form-control mt-1" onchange="NameValidation()" placeholder="Enter Full Name" value="" />
                            <span id="first_name_error" class="text-danger"></span>
                        </div>



                        <div class="form-group">
                        <b> Email: </b>
                            <input type="email" name="email" id="email" class="form-control mt-1" onchange="EmailValidation()" placeholder="Enter Email" value="" />
                            <span id="email_error" class="text-danger"></span>
                        </div>

                        
                        <div class="form-group">
                           <b> Phone Number: </b>
                            <input type="text" name="pnumber" id="pnumber" class="form-control mt-1" onchange="PhoneValidation()" placeholder="Your Phone Number *" value="" />
                            <span id="phone_error" class="text-danger"></span>
                        </div>


                        <div class="form-group">
                                <b> Car Reg: </b>
                            <input type="text" name="carReg" id="carReg" class="form-control mt-1" onchange="CarRegValidation()" placeholder="Enter Car Reg" value="" />
                            <span id="car_error" class="text-danger"></span>
                        
                        </div>



                    </div>


                    <div class="col-md-6">
                    <div class="contact-image mt-5">
                              <img src="img/cool.png">
                        </div>
                        <div class="form-group">
                                <b> Message: </b>
                            <textarea name="comment" id="comment" class="form-control mt-1" onchange="CommentValid()" placeholder="Your Message" style="width: 100%; height: 120px;"></textarea>
                            <span id="comment_error" class="text-danger"></span>
                        </div>

                        <div class="form-group">
                      
                        <button type="submit"  class="btn" name="contactus1" id="contactus1" style="margin-left: 33%; margin-top: -7px;">Submit</button> 
                        
                        </div>
                                
                    </div>

                   
                </div>
            </form>
</div>
					
					
					
					
					
					
                   
                        <div class='title'>
                            <p> </p>
                        </div>
                            <div class="single-blog-post post-style-4 d-flex align-items-center wow fadeInUpBig" data-wow-delay="0.1s" >
                                <!-- Post Thumbnail -->
                                <div class="post-thumbnail">
                                    <img src="img/quality.jpg" alt="">
                                </div>
                                <!-- Post Content -->
                                <div class="post-content">
                                    <a href="#" class="headline" >
                                        <h4>Quality Production</h4>
                                        <p style="font-size:18px; font-weight:bold" > Free Quote </p>
                                    </a>
                                    <p style="font-size:16px">Call us free on <a style="font-size:16px; color:black; font-weight:bold" href="tel:01279-817451">01279-817451</a> and we will arrange to pickup your turbo from anywhere in the UK next day,
                                        alternatively send us a email with your car registration number and contact details and we will send you a no obligation quotation to remanufacture your turbocharger. 
                                        To receive a quotation please send email by clicking<a style="font-size:16px; color:black; font-weight:bold" href="mailto:contact@aceturbo.co.uk"> ME <i class="fas fa-envelope"></i></a></p>
                                </div>
                            </div>
                            <div class="single-blog-post post-style-4 d-flex align-items-center wow fadeInUpBig" data-wow-delay="0.1s">
                                <!-- Post Content -->
                                <div class="post-content" style="padding-left:40px; padding-top:20px; padding-bottom:20px" >
                                        <p style="font-size:18px; font-weight:bold" >No hidden charges</p>
                                        <p style="font-size:16px">Once we receive your turbo we will strip clean and assess it for damage, 
                                            if your turbocharger has any damage to the housing or anything that is not part of a standard rebuild we will contact you to seek advice. 
                                            We do not carry out any unauthorised repair that’s our price promise.</p>
                                        <p style="font-size:18px; font-weight:bold" >Quality Parts</p>
                                        <p style="font-size:16px">As we give a 12 months parts & labour warranty with all our remanufactured turbochargers it does not pay to use cheap components sourced from the Far East, 
                                            all our replacement parts are sourced from UK based OEM suppliers.</p>
                                        <p style="font-size:18px; font-weight:bold" >Professional equipment</p>
                                        <p style="font-size:16px">Our remanufacturing facility is geared up to handle any kind of turbocharger and as such our equipment has to be A1. 
                                            All our equipment is brand new from the tools to do the job to the state of the art vibration rig to balance the turbochargers. 
                                            "If a job’s worth doing then its worth doing it well" is our motto.</p>
                                        <p style="font-size:18px; font-weight:bold" >Fast Turnaround.</p>
                                        <p style="font-size:16px">Once we receive your order we will dispatch your turbocharger the same day if we have not missed courier, 
                                            however if we don’t have your turbocharger in stock then we will arrange for your turbo to be picked up the following day from anywhere you want 
                                            (your garage , your home , your workplace). 
                                            Once we have received your turbo and assessed it we will remanufacture and get it back to you within a few days normally this process takes 4-5 days end to end.</p>
                                        <p style="font-size:18px; font-weight:bold" >Sending us your turbo
                                        <p style="font-size:16px">We just ask that it is drained of any oil and packed so it won’t get damaged in transit. 
                                            We only want the turbocharger in its housing with the actuator and nothing else. 
                                            If you send your turbocharger with the exhaust manifold we cannot be held responsible for any damage caused enroute and we may be 
                                            unable to remanufacture your turbocharger if we feel that turbo cannot be removed from the exhaust manifold without causing damage to either part.</p>
                                        <p style="font-size:18px; font-weight:bold" >Product Bulletins</p>
                                        <p style="font-size:16px">Our Turbochargers don’t normally fail as they are a high precision item, 
                                            so when a turbocharger does go bad prematurely then there is often an underlying reason. 
                                            This premature failure can be caused by any number of things and your mechanic should try to ascertain why it failed in the first place. 
                                            There are turbochargers which have design faults from the manufacturer and are known to fail prematurely, 
                                            to overcome this manufacturer’s design work arounds and issue product bulletins so the problem can be overcome.</p>
                                        <p style="font-size:16px">When we receive turbochargers that fit this category we will always send out instructions for you or your mechanics 
                                            to follow to ensure this problem is rectified if you do not carry out the changes required then there is a possibility that your turbo will fail prematurely.</p>
                                </div>
                            </div>
                    </div>
                
            </div>
        </div>
    </div>

<!-- Modal -->
<div class='modal fade' id='filterModal' tabindex='-1' role='dialog' aria-labelledby='filterModalTitle' aria-hidden='true'>
    <div class='modal-dialog modal-dialog-centered modal-md' role='document'>
        <div class='modal-content'>
            <div class='modal-header'>
                <h5 class='modal-title' id='exampleModalLongTitle'>Search Error</h5>
                <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                <span aria-hidden='true'>&times;</span>
                </button>
            </div>
            <div class='filter-modal-body'>
                ...
            </div>
            <div class='modal-footer'>
                <button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal End-->
<!-- Modal -->
<div class='modal fade' id='repairModal' tabindex='-1' role='dialog' aria-labelledby='repairModalTitle' aria-hidden='true'>
    <div class='modal-dialog modal-dialog-centered modal-md' role='document'>
        <div class='modal-content'>
            <div class='modal-header'>
                <h5 class='modal-title' id='exampleModalLongTitle'>Multiple Choice</h5>
                <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                <span aria-hidden='true'>&times;</span>
                </button>
            </div>
            <div class='repair-modal-body'>
                ...
            </div>
            <div class='modal-footer'>
                <button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal End-->
<footer class="footer-area">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-4">
                <div class="footer-single-widget">
                    <a href="index.php"><img src="img/logo.png" alt="" style="width:40%"></a>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="footer-single-widget">
                    <ul class="footer-menu d-flex justify-content-between">
                        <li><a href="index.php">Home</a></li>
                        <li class="nav-item dropdown" style="width: 120px">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Legal Stuff</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="businessPolicy.php">Business Policy</a>
                                <a class="dropdown-item" href="deliveryPolicy.php">Delivery Policy</a>
                                <a class="dropdown-item" href="refund.php">Refund/Cancellations</a>
                            </div>
                        </li>
                        <li><a href="cart.php">Cart</a></li>
                        <li class="nav-item dropdown" style="width: 100px">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="turboRepairs.php">Turbo Repairs</a>
                                <a class="dropdown-item" href="remanufactured.php">Remanufactured Turbos</a>
                                <a class="dropdown-item" href="turboParts.php">Turbo Parts</a>
                                <a class="dropdown-item" href="turboFitting.php">Turbo Fitting</a>
                                <a class="dropdown-item" href="newTurbos.php">New Turbos</a>
                            </div>
                        </li>
                        <li class="nav-item dropdown" style="width: 130px">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Turbo Finder</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="garretTurbos.php">Garret Turbos</a>
                                <a class="dropdown-item" href="holsetTurbos.php">Holset Turbos</a>
                                <a class="dropdown-item" href="ihiTurbos.php">IHI Turbos</a>
                                <a class="dropdown-item" href="mitsuTurbos.php">Mitsubishi Turbos</a>
                                <a class="dropdown-item" href="schwitzerTurbos.php">Schwitzer Turbos</a>
                                <a class="dropdown-item" href="toyotaTurbos.php">Toyota Turbos</a>
                                <a class="dropdown-item" href="kkkTurbos.php">KKK Turbos</a>
                            </div>
                        </li>
                        <li><a href="contact.php">Contact Us</a>
                            <!-- <a href="regnum1.php">Testing</a> -->
                            <a href="regnum2.php">Testing</a>
                        </li>

                    </ul>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="footer-single-widget">
                    <h5>Subscribe</h5>
                    <form action="#" method="post">
                        <input type="email" name="email" id="emailsub" placeholder="Enter your mail">
                        <button type="button"><i class="fa fa-arrow-right"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- ***** Footer Area End ***** -->

<!-- ****** FILTER FORM AJAX SCRIPTS *******-->
<script>
    var mk_id = 0;
    var md_id = 0;
    var sy_id = 0;
    var ey_id = 0;
    var y_idd = 0;

    function chooseModel1(make_id) {
        mk_id = make_id;
        var html = "<option value=''>Select Model:</option>";
        $.ajax({
            url: 'chooseModel.php',
            type: 'post',
            data: {
                'make_id': make_id
            },
            datatype: 'json',
            success: function(data) {
                data = jQuery.parseJSON(data);
                data.sort(GetSortOrder("model_name"));
                console.log(data);
                $.each(data, function(key, value) {
                    html += "<option value=" + value.model_id + ">" + value.model_name + "</option>"
                });
                //modelarray.sort();
                //console.log(modelarray.length);
                $("#model1").empty();
                $("#model1").append(html);
            }
        })
    }
    var minn;
    var max;

    function chooseYear1(model_id) {
        minn = 100000;
        max = 0;
        md_id = model_id;
        console.log(md_id);
        var i = 0;
        var html = "<option value=''>Select Year:</option>";
        $.ajax({
            url: 'chooseYear.php',
            type: 'post',
            data: {
                'modl_id': model_id
            },
            datatype: 'json',
            success: function(data) {
                data = jQuery.parseJSON(data);
                $.each(data, function(key, value) {

                    if (max < value.end_year) {
                        max = value.end_year;

                    }
                    if (minn >= value.start_year && value.start_year != 0) {
                        minn = value.start_year;

                    }

                });

                sy_id = minn;
                ey_id = max;
                for (i = minn; i <= max; i++) {
                    html += "<option value=" + i + ">" + i + "</option>";
                }

                $("#year1").empty();
                $("#year1").append(html);
            }
        })
    }

    function chooseEngine1(year_id) {
        y_idd = year_id;
        console.log(md_id);
        console.log(minn);
        console.log(max);
        console.log(year_id);
        var temp = 90;

        var html = "<option value=''>Engine Size:</option>";
        $.ajax({
            url: 'chooseEngine.php',
            type: 'post',
            data: {
                'make_id': mk_id,
                'model_id': md_id,
                's_yr': sy_id,
                'e_yr': ey_id,
                'y_id': year_id

            },
            datatype: 'json',
            success: function(data) {
                data = jQuery.parseJSON(data);
                data.sort(GetSortOrder("engine"));
                console.log(data);

                //const uarray = new Set(data);
                //const data1 = [...uarray];
                //const data1 = data.filter(distinct1);
                //var data1 = data.filter((v, i, a) => a.indexOf(v) === i);
                //console.log(data1);
                $.each(data, function(key, value) {

                    if (temp != value.engine) {
                        html += "<option value=" + value.engine + ">" + value.engine + "</option>"
                        temp = value.engine;
                    }
                });
                $("#engine1").empty();
                $("#engine1").append(html);
            }
        })
    }

    function chooseBHP1(engine_size) {
        // console.log(mk_id);
        // console.log(md_id);
        // console.log(minn);
        // console.log(max);
        // console.log(engine_size);
        // console.log(y_idd);
        temp1 = 10000;
        var html = "<option value=''>Select BHP:</option>";
        $.ajax({
            url: 'chooseBHP.php',
            type: 'post',
            data: {
                'make_id': mk_id,
                'model_id': md_id,
                //'s_yr': sy_id,
                //'e_yr': ey_id
                'y_id': y_idd,
                'e_size': engine_size

            },
            datatype: 'json',
            success: function(data) {
                //console.log(data);
                data = jQuery.parseJSON(data);
                data.sort(GetSortOrder("power1"));
                //console.log(data);
                $.each(data, function(key, value) {
                    if (temp1 != value.power1) {
                        html += "<option value=" + value.power1 + ">" + value.power1 + "</option>"
                        temp1 = value.power1;
                    }
                });
                $("#bhp1").empty();
                $("#bhp1").append(html);
            }
        })
    }
</script>
<script>
    var mk_id = 0;
    var md_id = 0;
    var sy_id = 0;
    var ey_id = 0;
    var y_idd = 0;

    function GetSortOrder(prop) {
        return function(a, b) {
            if (a[prop] > b[prop]) {
                return 1;
            } else if (a[prop] < b[prop]) {
                return -1;
            }
            return 0;
        }
    }

    function chooseModel(make_id) {
        mk_id = make_id;
        var html = "<option disabled selected value=''>Select Model:</option>";
        $.ajax({
            url: 'chooseModel.php',
            type: 'post',
            data: {
                'make_id': make_id
            },
            datatype: 'json',
            success: function(data) {
                data = jQuery.parseJSON(data);
                data.sort(GetSortOrder("model_name"));
                // console.log(data);
                $.each(data, function(key, value) {
                    html += "<option value=" + value.model_id + ">" + value.model_name + "</option>"
                });
                //modelarray.sort();
                //console.log(modelarray.length);
                $("#model").empty();
                $("#model").append(html);
            }
        })
    }


    var minn;
    var max;

    function chooseYear(model_id) {
        minn = 100000;
        max = 0;
        md_id = model_id;
        // console.log(md_id);
        var i = 0;
        var html = "<option value=''>Select Year:</option>";
        $.ajax({
            url: 'chooseYear.php',
            type: 'post',
            data: {
                'modl_id': model_id
            },
            datatype: 'json',
            success: function(data) {
                data = jQuery.parseJSON(data);
                $.each(data, function(key, value) {

                    if (max < value.end_year) {
                        max = value.end_year;

                    }
                    if (minn >= value.start_year && value.start_year != 0) {
                        minn = value.start_year;

                    }

                });

                sy_id = minn;
                ey_id = max;
                for (i = minn; i <= max; i++) {
                    html += "<option value=" + i + ">" + i + "</option>";
                }

                $("#year").empty();
                $("#year").append(html);
            }
        })
    }

    function chooseEngine(year_id) {
        y_idd = year_id;
        // console.log(md_id);
        // console.log(minn);
        // console.log(max);
        // console.log(year_id);
        var temp = 90;

        var html = "<option value=''>Engine Size:</option>";
        $.ajax({
            url: 'chooseEngine.php',
            type: 'post',
            data: {
                'make_id': mk_id,
                'model_id': md_id,
                's_yr': sy_id,
                'e_yr': ey_id,
                'y_id': year_id

            },
            datatype: 'json',
            success: function(data) {
                data = jQuery.parseJSON(data);
                data.sort(GetSortOrder("engine"));
                // console.log(data);

                //const uarray = new Set(data);
                //const data1 = [...uarray];
                //const data1 = data.filter(distinct1);
                //var data1 = data.filter((v, i, a) => a.indexOf(v) === i);
                //console.log(data1);
                $.each(data, function(key, value) {

                    if (temp != value.engine) {
                        html += "<option value=" + value.engine + ">" + value.engine + "</option>"
                        temp = value.engine;
                    }
                });
                $("#engine").empty();
                $("#engine").append(html);
            }
        })
    }

    function chooseBHP(engine_size) {
        // console.log(mk_id);
        // console.log(md_id);
        // console.log(minn);
        // console.log(max);
        // console.log(engine_size);
        // console.log(y_idd);
        temp1 = 10000;
        var html = "<option value=''>Select BHP:</option>";
        $.ajax({
            url: 'chooseBHP.php',
            type: 'post',
            data: {
                'make_id': mk_id,
                'model_id': md_id,
                //'s_yr': sy_id,
                //'e_yr': ey_id
                'y_id': y_idd,
                'e_size': engine_size

            },
            datatype: 'json',
            success: function(data) {
                //console.log(data);
                data = jQuery.parseJSON(data);
                data.sort(GetSortOrder("power1"));
                // console.log(data);
                $.each(data, function(key, value) {
                    if (temp1 != value.power1) {
                        html += "<option value=" + value.power1 + ">" + value.power1 + "</option>"
                        temp1 = value.power1;
                    }
                });
                $("#bhp").empty();
                $("#bhp").append(html);
            }
        })
    }


    function subtotal(qty, price, i, j) {
        const b = i;
        //console.log(i);
        $.ajax({
            url: 'subTotal.php',
            type: 'post',
            data: {
                'qty': qty,
                'price': price
            },
            datatype: 'json',
            success: function(data) {
                //console.log(data);
                data = jQuery.parseJSON(data);
                const a = 'subt ${b}';
                //console.log(a);

                document.getElementById('subt' + i).innerHTML = data;
                //var html = "<td>" + data + "</td>";
                //$("#subt").empty();
                // $("#subt").append(html);
            }
        })
    }

    function total(i, a) {
        var arr = [];
        for (x = 1; x <= i; x++) {
            arr[x - 1] = document.getElementById('subt' + x).innerHTML;
        }
        var sum = 0.00;
        for (y = 0; y < i; y++) {
            sum = sum + parseFloat(arr[y]);
        }
        var n = sum.toFixed(2);
        document.getElementById('subtotal').innerHTML = n;
        document.getElementById('dev').innerHTML = a;
        var sum1 = parseFloat(n) + parseFloat(a);
        var per = (sum1 * 20) / 100;
        var per1 = per.toFixed(2);
        document.getElementById('tax').innerHTML = per1;
        var tot = parseFloat(n) + parseFloat(a) + parseFloat(per1);
        var tot1 = tot.toFixed(2);
        document.getElementById('tot').innerHTML = tot1;
        var test = document.getElementById('qty').innerHTML;
        document.getElementById('pid').value = test;
    }
</script>
<script>
    var myButton;
    var myButton1;
    var myButton2;
    var myButton3;
    var myButton4;
    var totall1;
    var sub = document.getElementById('subtotal').innerHTML;

    function tot1(c) {

        var arr = [];
        for (x = 0; x < c; x++) {
            arr[x] = document.getElementById('sub' + x).innerHTML;
        }
        var sum = 0.00;
        for (y = 0; y < c; y++) {
            sum = sum + parseFloat(arr[y]);
        }
        var n = sum.toFixed(2);
        //alert(n);
        document.getElementById('subtotal').innerHTML = n;
        if (n > 50) {
            document.getElementById("vtype1").disabled = false;
            document.getElementById("vtype1").checked = true;
        } else {
            document.getElementById("vtype1").disabled = true;
            document.getElementById("vtype2").checked = true;
        }
        sub = document.getElementById('subtotal').innerHTML;
        if (document.getElementById('vtype1').checked) {
            var totall = parseFloat(sub) + parseFloat(0);
            var totall1 = totall.toFixed(2);
            document.getElementById('totalamount').innerHTML = totall1;
            document.getElementById('totalprice').value = totall1;
        } else if (document.getElementById('vtype2').checked) {
            var totall = parseFloat(sub) + parseFloat(10);
            var totall1 = totall.toFixed(2);
            document.getElementById('totalamount').innerHTML = totall1;
            document.getElementById('totalprice').value = totall1;

        }
        normal(c);

    }
    if (document.getElementById('vtype1').checked) {
        var totall = parseFloat(sub) + parseFloat(0);
        var totall1 = totall.toFixed(2);
        document.getElementById('totalamount').innerHTML = totall1;
        document.getElementById('totalprice').value = totall1;
    } else if (document.getElementById('vtype2').checked) {
        var totall = parseFloat(sub) + parseFloat(10);
        var totall1 = totall.toFixed(2);
        document.getElementById('totalamount').innerHTML = totall1;
        document.getElementById('totalprice').value = totall1;

    }

    function normal(n) {
        if (document.getElementById('vtype1').checked) {
            var totall = parseFloat(sub) + parseFloat(0);
            var totall1 = totall.toFixed(2);
            document.getElementById('totalamount').innerHTML = totall1;
            document.getElementById('totalprice').value = totall1;

        } else if (document.getElementById('vtype2').checked) {
            var totall = parseFloat(sub) + parseFloat(10);
            var totall1 = totall.toFixed(2);
            document.getElementById('totalamount').innerHTML = totall1;
            document.getElementById('totalprice').value = totall1;
        }
    }

    function subt1(v, id, i, c) {
        //alert(c);
        $.ajax({
                url: 'subTot1.php',
                type: 'post',
                data: {
                    'qty': v,
                    'id': id
                },
                datatype: 'json',
                success: function(data) {
                    data = jQuery.parseJSON(data);
                    var data1 = data.toFixed(2);
                    document.getElementById('sub' + i).innerHTML = data1;
                    tot1(c);

                    //document.getElementById('subt' + i).innerHTML = data;
                    //var html = "<td>" + data + "</td>";
                    //$("#subt").empty();
                    // $("#subt").append(html);
                }

            })
            //document.getElementById('sub' + i).innerHTML;
    }
</script>
<script>
    function countCart() {
        $.ajax({
            url: 'count.php',
            type: 'post',
            data: {

            },
            //datatype: 'json',
            success: function(data) {
                //data = jQuery.parseJSON(data);
                document.getElementById('cart-count').innerHTML = data;
                document.getElementById('cart-count101').innerHTML = data;
            }

        })
    }

    function repaircoupon(dat) {
        $('.repair-modal-body').load('repairpop.php?dat=' + dat, function() {
            $('#repairModal').modal({
                show: true
            });
        });
    }

    function addToCart(qty, id, pname, spart) {
        // console.log(pname);
        // console.log(spart);
        $.ajax({
            url: 'adding.php',
            type: 'post',
            data: {
                'cid': id,
                'quant': qty,
                'part': pname,
                'supp': spart
            },
            //datatype: 'json',
            success: function(data) {
                //data = jQuery.parseJSON(data);
                if (data != 0.1) {
                    repaircoupon(data);
                }
                countCart();
            }

        })
    }

    function cartDetails() {
        var count = document.getElementById("cart-count").innerHTML;
        var count = parseInt(count);
        if (count == 0) {
            document.getElementById("deliv").style.display = "none";
        }
    }
</script>


<!-- jQuery (Necessary for All JavaScript Plugins) -->
<script src="js/jquery/jquery-2.2.4.min.js"></script>
<!-- Popper js -->
<script src="js/popper.min.js"></script>
<!-- Bootstrap js -->
<script src="js/bootstrap.min.js"></script>
<!-- Plugins js -->
<script src="js/plugins.js"></script>
<!-- Active js -->
<script src="js/active.js"></script>
<script>
    var slideIndex = 0;
    showSlides();

    function showSlides() {
        var i;
        var slides = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("dot");
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex++;
        if (slideIndex > slides.length) {
            slideIndex = 1
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active1", "");
        }
        slides[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " active1";
        setTimeout(showSlides, 2000); // Change image every 2 seconds
    }
</script>
<script>
    var slideIndex = 1;
    showSlides(slideIndex);

    function plusSlides(n) {
        showSlides(slideIndex += n);
    }

    function currentSlide(n) {
        showSlides(slideIndex = n);
    }

    function showSlides(n) {
        var i;
        var slides = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("demo");
        var captionText = document.getElementById("caption");
        if (n > slides.length) {
            slideIndex = 1
        }
        if (n < 1) {
            slideIndex = slides.length
        }
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " active";
        captionText.innerHTML = dots[slideIndex - 1].alt;
    }
</script>
<script>
    function modal1(idd) {
        $('.modal-body').load('pop.php?id=' + idd, function() {
            $('#exampleModalCenter').modal({
                show: true
            });
        });
    }

    function modal2() {
        $('.modal-body2').load('formpop.php', function() {
            $('#exampleModalCenter1').modal({
                show: true
            });
        });
    }

    function shippingForm(shipp) {
        if (shipp.checked == true) {
            document.getElementById("shipform").style.display = "block";
        } else {
            document.getElementById("shipform").style.display = "none";
        }
    }
</script>
<script src="admin/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="admin/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

<script>
    $(function() {
        $("#example1").DataTable({
            "responsive": true,
            "autoWidth": false,
        });
        $('#example2').DataTable({
            "paging": false,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "autoWidth": false,
            "responsive": false,
            "info": false,
        });
    });
</script>
<script>
    document.addEventListener("DOMContentLoaded", () => {
        const rows = document.querySelectorAll("tr[data-href");
        rows.forEach(row => {
            row.addEventListener("click", () => {
                window.location.href = row.dataset.href;
            });
        });
    });
</script>
<script>
    window.addEventListener('keydown', function(e) {
        if (e.keyIdentifier == 'U+000A' || e.keyIdentifier == 'Enter' || e.keyCode == 13) {
            if (e.target.nodeName == 'INPUT' && e.target.type == 'number') {
                e.preventDefault();
                return false;
            }
        }
    }, true);
</script>
<script>
    function filtercoupon() {
        $('.filter-modal-body').load('filterpop.php', function() {
            $('#filterModal').modal({
                show: true
            });
        });
    }

    function validateForm() {
        if (document.forms["mainFilter"]["make"].value == "" || document.forms["mainFilter"]["model"].value == "" ||
            document.forms["mainFilter"]["year"].value == "" || document.forms["mainFilter"]["engine"].value == "" || document.forms["mainFilter"]["bhp"].value == "") {
            filtercoupon();
            return false;
        }
    }
</script>
<script>
    function currentDiv(n) {
        showDivs(slideIndex = n);
    }

    function showDivs(n) {
        var i;
        var x = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("demo");
        if (n > x.length) {
            slideIndex = 1
        }
        if (n < 1) {
            slideIndex = x.length
        }
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" w3-opacity-off", "");
        }
        x[slideIndex - 1].style.display = "block";
        dots[slideIndex - 1].className += " w3-opacity-off";
    }
</script>
<script>
    $(function() {

        $('#turbo').keyup(function() {
            var letter1 = null;
            letter1 = $(this).val();

            // If a letter was found
            if (letter1 !== null) {
                //console.log(letter1[0]);
                //alert(letter1[0]);
                // Change it to lowercase and update the value
                if ((letter1[0] == 4) || (letter1[0] == 7) || (letter1[0] == 8)) {
                    $('#turbo').attr('minlength', 5);
                } else if (letter1[0] == 5) {
                    $('#turbo').attr('minlength', 9);
                } else if (letter1[0] == 1) {
                    $('#turbo').attr('minlength', 8);
                } else {
                    $('#turbo').attr('minlength', 1);
                }

                // Do the request
            }
        });
    });
</script>


<script>
    window.onload = createCaptcha1; /* createCaptcha1 function generate randome captcha everytime page loads */
    function createCaptcha1() { /* function for generating random captcha */
        var letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789abcdefghijklmnopqrstuvwxyz";
        var a = letters[Math.floor(Math.random() * letters.length)]; /* function generating random captcha */
        var b = letters[Math.floor(Math.random() * letters.length)];
        var c = letters[Math.floor(Math.random() * letters.length)];
        var d = letters[Math.floor(Math.random() * letters.length)];
        var e = letters[Math.floor(Math.random() * letters.length)];
        code = a + b + c + d + e; /* randomly generated captcha adds up & stored in "code" variable */
        document.getElementById("captchaId").innerHTML = code; /* displaying captcha on User Interface */
    }

    function validateCaptcha() { /* Validate Captcha on Runtime */
        rec = document.getElementById("captcha").value;

        if (rec == "") {
            document.getElementById("captcha_error").innerHTML = "Please Enter Captcha for Verification";
            document.getElementById("captcha_matched").innerHTML = "";
            return false;
        } else if (code.match(rec)) {
            document.getElementById("captcha_error").innerHTML = "";
            document.getElementById("captcha_matched").innerHTML = "Captcha Matched";

        } else if (!(code.match(rec))) {
            document.getElementById("captcha_error").innerHTML = "Incorrect Captcha";
            document.getElementById("captcha_matched").innerHTML = "";
            return false;
        }
    }

    function NameValidation() { /* Validate Name on Runtime */

        var valid = document.getElementById("name").value;
        var format = /^(?![\s.]+$)[a-zA-Z\s.]*$/;
        if (!(valid.match(format))) {
            document.getElementById("first_name_error").innerHTML = "Please Enter Alphabets Only";
            return false;
        } else if (valid.match(format)) {
            document.getElementById("first_name_error").innerHTML = "";
            return true;
        }
    }

    function PhoneValidation() { /* Validate Phone Number on Runtime */
        var phoneValid = document.getElementById("pnumber").value;
        var phoneFormat = /^[0-9][-\][0-9]+$/;
        if (!(phoneValid.match(phoneFormat))) {
            document.getElementById("phone_error").innerHTML = "Please Enter Digits Only";
            // console.log("PHONE NOT MATCHED");
            return false;
        } else if (phoneValid.match(phoneFormat)) {
            // console.log("right");
            document.getElementById("phone_error").innerHTML = "";
            return true;
        }
    }

    function EmailValidation() { /* Validate Email on Runtime */
        var emailValid = document.getElementById("email").value;
        var emailFormat = "@";
        if (!(emailValid.match(emailFormat))) {
            document.getElementById("email_error").innerHTML = "@ Must Be Included In Email";
            return false;
        } else if (emailValid.match(emailFormat)) {
            document.getElementById("email_error").innerHTML = "";
            return true;
        }
    }

    function CommentValid() /* Validate Comment on Runtime */ {
        var comment1 = document.getElementById("comment").value;
        // console.log(comment1);
        if (comment1 == "") {
            document.getElementById("comment_error").innerHTML = "Comments Should Not Be Empty";
        }
    }

    function CarRegValidation() /* Validate Comment on Runtime */ {
        var carReg1 = document.getElementById("carReg").value;
        // console.log(comment1);
        if (carReg1 == "") {
            document.getElementById("car_error").innerHTML = "Car Registration Should Not Be Empty";
            return false;
        }
    }


    function formValidation() { /* onsubmit Function */
        /* Rechecking all validations before submitting the Form */
        var valid = document.getElementById("name").value;
        var format = /^(?![\s.]+$)[a-zA-Z\s.]*$/; /* Regular Expression for Name */

        if (!(valid.match(format))) {
            document.getElementById("first_name_error").innerHTML = "Please Enter Alphabets Only";
            return false;
        }
        if (valid.match(format)) {
            document.getElementById("first_name_error").innerHTML = "";
        }
        if(valid=="")
        {
            document.getElementById("first_name_error").innerHTML = "Name should not be empty";
            return false;
        }

        

        var emailValid = document.getElementById("email").value;
        var emailFormat = "@"; /* Email must include @ */
        if (!(emailValid.match(emailFormat))) {
            document.getElementById("email_error").innerHTML = "@ Must Be Included In Email";
            return false;
        }
        if (emailValid.match(emailFormat)) {
            document.getElementById("email_error").innerHTML = "";
        }
        if(emailValid=="")
        {
            document.getElementById("email_error").innerHTML = "Email should not be Empty";
            return false;
        }


        var phoneValid = document.getElementById("pnumber").value;
        var phoneFormat = /^[0-9][-\][0-9]+$/; /* Regular Expression for Phone Number */
        if (!(phoneValid.match(phoneFormat))) {
            console.log("not");
            document.getElementById("phone_error").innerHTML = "Please Enter Digits Only";
            return false;
        }
        if (phoneValid.match(phoneFormat)) {
            console.log("right");
            document.getElementById("phone_error").innerHTML = "";
        }


        var carReg1 = document.getElementById("carReg").value;
        // console.log(comment1);
        if (carReg1 == "") {
            document.getElementById("car_error").innerHTML = "Car Registration Should Not Be Empty";
            return false;
        }
        else
        {
            document.getElementById("car_error").innerHTML = "";
        }

        var comment = document.getElementById("comment").value;
        if (comment == "") {
            document.getElementById("comment_error").innerHTML = "Comments Should Not Be Empty";
            return false;
        }
        else
        {
            document.getElementById("comment_error").innerHTML = "";
        }

      

        rec = document.getElementById("captcha").value;
        if (code != rec) {
            document.getElementById("captcha_error").innerHTML = "Incorrect Captcha";
            document.getElementById("captcha_matched").innerHTML = "";
            return false;
        }
        modalEmail(); /*Function will only run when all the validations are True on onsubmit */
    }
</script>

<script>
    function modalEmail() { /*Email Popup Function for Successful Email Send */
        $('.email-modal-body').load('emailsuccessful.php', function() {
            $('#emailModal').modal({
                show: true
            });
        });
    }
</script>
</html>
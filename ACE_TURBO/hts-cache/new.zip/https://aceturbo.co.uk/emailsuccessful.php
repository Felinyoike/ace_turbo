

    <h2 style='text-align:center; padding:20px; color:green'>EMAIL SENT SUCCESSFULLY</h2>
